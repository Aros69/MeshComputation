# TP Mesh Computation M2 ID3D

- Ali 	Zahidi  p1713059
- Robin Donnay	p1510329

## Remarques
- Toutes les fonctions et prédicats (ainsi que les ajouts pour Voronoi) ont été implémenté sauf l'insertion de Delaunay.  
- Le calcul du Laplacien est lent sur le maillage de reine... Patience.  
